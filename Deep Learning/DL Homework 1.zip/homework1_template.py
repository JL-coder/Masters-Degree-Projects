import numpy as np

def problem_1a (A, B):
    return A + B

def problem_1b (A, B, C):
    return (A @ B) - C

def problem_1c (A, B, C):
    return (A * B) + C.T

def problem_1d (x, y):
    return np.sum(x.T * y)
    #Can also use numpy.inner function
    #return np.inner(x,y)

def problem_1e (A, x):
    return (np.linalg.solve(A, x))

def problem_1f (A, x):
    trans = np.linalg.solve(A.T, x.T)
    return trans.T
    #return np.linalg.solve(x, np.linalg.inv(A))

def problem_1g (A, i):
    return np.sum(A[i, ::2])

def problem_1h (A, c, d):
    greater = A[np.nonzero(A > c)]
    less = greater[np.zero(greater < d)]
    return np.mean(less)

def problem_1i (A, k):
    a,b = np.linalg.eig(A)
    print(a.shape)
    print(b.shape)
    idx_a = np.argsort(a)[::-1]
    i = idx_a[:k] 
    ans = b[:,i]
    return ans
    #evals = np.linalg.eig(A)[1]
    #col = A.shape - k
    #return evals[:, col]

def problem_1j (x, k, m, s):
    # x = column vector
    # k = integer
    # m = positive scalar
    # s = positive scalar
    # return n x k matrix w/ Gaus dist N(x + mz, sI)
    # z col vector w/ n componenets containing all ones
    #I = id matrix
    z = np.ones(len(x))
    mean = (x + m * z)
    cov = s * np.identity(len(x))
    ans = np.random.multivariate_normal(mean, cov, k).T
    return ans
    #return np.random.multivariate_normal(np.array(x,k) + (m * np.ones(x,k), s * np.identity(k)))
    #return (np.random.randn(x, k) + (m * np.ones(x, k)), s * np.identity(k))

def problem_1k (A):
    #np.random.shuffle only shuffles axis = 1 
    return np.random.permutation(x)

def problem_1l (x):
    y = (x - np.mean(x)) / np.std(x)
    return y

#Not sure about this one
def problem_1m (x, k):
    vec = x[:, np.newaxis]
    #print(vec)
    return np.repeat(vec, k, axis = 1)

def problem_1n (X):
    #input matrix m x n
    #output n x n matrix w/ pairwise L2 distance ||x^ i - x^j||^2
    #Expand L2 distance: ||x^ i - x^j||^2 = x(^i)^2 + x(^j)^2 - 2x(^i)x(^j)
    #need transpose so X * X^T = n x n
    #use newaxis to transpose last row vector that comes out of np.sum back into a column vector

    x2=np.atleast_3d(X)
    x3=np.repeat(x2,X.shape[1],2)

    #print(x3.shape)

    x5=X[np.newaxis,...]
    x6=np.repeat(x5,X.shape[1],0)
    x7=x6.copy()
    x8=np.swapaxes(x7,0,1)

    #print(x8.shape)

    x9=np.square(x3-x8)
    #print(x9.shape)
    D=np.sqrt(np.sum(x9,axis=0))

    return D

    #distance = -2 * np.dot(X, X.T) + np.sum(X ** 2, axis = 1) + np.sum(X ** 2, axis = 1)[:, np.newaxis]
    #return distance

def linear_regression (X_tr, y_tr):
    X_tr = X_tr.T
    w = np.linalg.solve(np.dot(X_tr, X_tr.T), np.dot(X_tr, y_tr))
    return w

def train_age_regressor ():
    # Load data
    X_tr = np.reshape(np.load("age_regression_Xtr.npy"), (-1, 48*48))
    ytr = np.load("age_regression_ytr.npy")
    X_te = np.reshape(np.load("age_regression_Xte.npy"), (-1, 48*48))
    yte = np.load("age_regression_yte.npy")

    #X_tr = X_tr.T
    w = linear_regression(X_tr, ytr)
    # Report fMSE cost on the training and testing data (separately)

    #Predict value - train data
    y_hat = np.dot(X_tr, w)
    #Get loss on training data 
    loss = y_hat - ytr

    list1=[print(" ",round(y_hat[i],1)," - ",ytr[i],"  =  ",round(loss[i],1))  for i in range (10)]

    Fmse_train = np.square(y_hat - ytr)
    print("\nF_MSE_train first 10 values: \n",Fmse_train[0:10])
    print("\nfinal value of F_MSE_train: \n",(np.mean(Fmse_train)/2))

    #Predict value - test data
    y_hat_test = np.dot(X_te, w)
    #Loss on test data
    loss_test = y_hat_test - yte

    list1=[print(" ",round(y_hat_test[i],1)," - ",yte[i],"  =  ",round(loss_test[i],1))  for i in range (10)]
    Fmse_test = np.square(y_hat_test - yte)

    print("\nF_MSE_test first 10 values: \n",Fmse_test[0:10])
    print("\nfinal value of F_MSE_test: \n",(np.mean(Fmse_test)/2))

#train_age_regressor()
x = np.arange(9).reshape(3,3)
y = np.arange(4).reshape(-1)
#print(x)
#np.random.shuffle(x)
#print(x)
#print(np.random.permutation(x))
#print(problem_1k(x))
#print(problem_1d(x, y))
#print(problem_1i(x, 2))
#print(problem_1n(x))
#print(problem_1m(x, 2))