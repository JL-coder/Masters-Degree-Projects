package org.example;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileUtil;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Random;
import java.util.HashMap;
import org.apache.hadoop.fs.FileSystem;

public class means {
    //Create mapper class
    // Update config(Round) to + 1
    public static class kMapper extends Mapper<Object, Text, Text, Text> {
        //Use hashmap to store the cached coordinates for the centroids
        String kcent;
        HashMap<String, String> cachedCoordinates = new HashMap<>();

        //List<Text> centers = new ArrayList<>();
        @Override
        protected void setup(Context context) throws IOException {
            Configuration configuration = context.getConfiguration();
            kcent = configuration.get("K_centroids");
            FileSystem fileSystem = FileSystem.get(configuration);
            BufferedReader ip = new BufferedReader(new InputStreamReader(fileSystem.open(new Path(kcent))));
            String line;
            while ((line = ip.readLine()) != null) {
                System.out.println(line);
                String[] L1 = line.split(",");
                cachedCoordinates.put(L1[0], L1[1] + "," + L1[2]);
            }
        }

        public void mapper(Object key, Text value, Context context) throws IOException, InterruptedException {
            Text centID = new Text();
            double min_cent_val = Double.POSITIVE_INFINITY;
            double distance;
            String ID = "";
            String[] xyVals = value.toString().split(",");
            for (String keyval : cachedCoordinates.keySet()) {
                String[] centList = cachedCoordinates.get(keyval).split(",");
                double val_x = Double.parseDouble(centList[0]);
                double val_y = Double.parseDouble(centList[1]);
                distance = Math.sqrt(Math.pow((Double.parseDouble(xyVals[0]) - val_x), 2) + Math.pow(Double.parseDouble(xyVals[1]) - val_y, 2));
                if (distance < min_cent_val) {
                    min_cent_val = distance;
                    ID = keyval;
                }
            }
            centID.set(ID);
            context.write(centID, value);
        }
    }
    public static class kCombiner extends Reducer<Text, Text, Text, Text> {
        public void reduce(Text key, Iterable<Text> value, Context context) throws IOException, InterruptedException {
            //In combiner get value of x/y (later will be averaged) and count of all instances from data
            double avg_x = 0;
            double avg_y = 0;
            double count = 0;
            for (Text str: value) {
                String[] data = str.toString().split(",");
                avg_x += Double.valueOf(data[0]);
                avg_y += Double.valueOf(data[1]);
                count += 1;
            }
            //write information to context

            context.write(key, new Text(Double.toString(avg_x) + "," + Double.toString(avg_y) + "," + Double.toString(count)));
        }
    }
    public static class kReducer extends Reducer<Text, Text, Text, NullWritable> {
        private Text out_Cent = new Text();
        public void reduce(Text key, Iterable<Text> value, Context context) throws IOException, InterruptedException {
            //In reducer get value of x/y and count
            double avg_x = 0;
            double avg_y = 0;
            double count = 0;
            for (Text str: value) {
                String[] data = str.toString().split(",");
                avg_x += Double.valueOf(data[0]);
                avg_y += Double.valueOf(data[1]);
                count += Double.valueOf(data[2]);
            }
            //Create a string out of the updated centroid values
            String new_Cent = String.format("%.3f", avg_x/count) + "," + String.format("%.3f", avg_y/count);
            out_Cent.set(key.toString() + "," + new_Cent);
            //write information to context with using count to get the average value of x/y
            context.write(out_Cent, NullWritable.get());
        }
    }

    public static void main(String[] args) throws Exception {
        // Setting seed to ensure reproducability
        Random rand = new Random();
        //Number of k values
        int K = Integer.parseInt(args[0]);
        PrintWriter writer = new PrintWriter("startcentroids.txt", "UTF-8");
        for(int i =1;i<(K+1);i++){
            int a = rand.nextInt(10000);
            int b = rand.nextInt(10000);
            writer.println(i+","+a+","+b); }
        writer.close();
        Configuration conf = new Configuration();
        FileSystem fs = FileSystem.get(conf);
        Path sPath = new Path("startcentroids.txt");
        String filename = "hdfs://localhost:9000/cs585/startcentroids/";
        Path dPath = new Path(filename);
        fs.copyFromLocalFile(false, sPath, dPath);
        conf.set("K_centroids", filename);
        //Repeat for 6 iterations
        for(int i = 0; i < 5; i++) {
            Job job = Job.getInstance(conf, "Problem 3 K_means");
            job.setJarByClass(means.class);
            job.setMapperClass(kMapper.class);
            job.setReducerClass(kReducer.class);
            //Can try and add if time permits
            //job.setCombinerClass(kCombiner.class);

            job.setMapOutputValueClass(Text.class);
            job.setOutputKeyClass(Text.class);
            job.setOutputValueClass(NullWritable.class);
            //job.setNumReduceTasks(5);
            FileInputFormat.addInputPath(job, new Path(args[1]));
            // args[1] == /cs585/project2/
            // koutput.txt
            FileOutputFormat.setOutputPath(job, new Path(args[1] + i));
            job.waitForCompletion(true);
            FileUtil.copyMerge(fs, new Path(args[2] + i), fs, new Path(args[2] + i + "result.txt"), true, conf, null);
            filename = args[2] + i + "result.txt";
            conf.set("K_centroids", filename);
        }
    }
}
