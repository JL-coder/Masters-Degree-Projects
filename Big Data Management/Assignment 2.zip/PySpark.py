import os
os.environ['JAVA_HOME'] = "C:/Users/joshu/Desktop/Big_Data_Management/jre/bin"
from pyspark.sql import SparkSession
from pyspark import SparkContext, SparkConf

spark = SparkSession.builder.master("spark://localhost:7077").getOrCreate()