package data;
import com.opencsv.CSVWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class problem1data {

    /*
    Data P (2d Points)
    Data R (2d Rectangles)

    Space extends 1-10k inclusive in x and y
    P - point (x,y) per line
    R - rect (bottomleft_x, bottomleft_y, h, w) - random variables y h in range [1,20],[1,5]
    */

    public static void main(String[] args){
        // Files
        String datasetP = "src/main/resources/datasetP.csv";
        String datasetR = "src/main/resources/datasetR.csv";
        File fileP = new File(datasetP);
        File fileR = new File(datasetR);
        // Setting seed
        long seed = 0;
        Random random = new Random(seed);

        try{
            FileWriter outputP = new FileWriter(fileP);
            FileWriter outputR = new FileWriter(fileR);

            // Csv Writer options
            CSVWriter writerP = new CSVWriter(outputP,     CSVWriter.DEFAULT_SEPARATOR,
                    CSVWriter.NO_QUOTE_CHARACTER,
                    CSVWriter.DEFAULT_ESCAPE_CHARACTER,
                    CSVWriter.RFC4180_LINE_END);
            CSVWriter writerR = new CSVWriter(outputR,     CSVWriter.DEFAULT_SEPARATOR,
                    CSVWriter.NO_QUOTE_CHARACTER,
                    CSVWriter.DEFAULT_ESCAPE_CHARACTER,
                    CSVWriter.RFC4180_LINE_END);


            // Generate data
            List<String[]> allP = new ArrayList<>();
            int min = 0;
            int max = 10000;
            for(int i = 0; i <= 50000; i++){
                String[] point = new String[2];
                // Select a random x and y point
                // min = 0, max = 10000
                point[0] = String.valueOf(ThreadLocalRandom.current().nextInt(min, max + 1));
                point[1] = String.valueOf(ThreadLocalRandom.current().nextInt(min, max + 1));
                allP.add(point);
            }
            // w range = [1,20]
            // h range = [1,5]
            int wmin = 1;
            int wmax = 20;
            int hmin = 1;
            int hmax = 5;
            List<String[]> allR = new ArrayList<>();
            for(int j = 0; j <= 10000; j++){
                String[] rect = new String[4];

                // gen bottom l and r
                rect[0] = String.valueOf(ThreadLocalRandom.current().nextInt(min, max + 1));
                rect[1] = String.valueOf(ThreadLocalRandom.current().nextInt(min, max + 1));

                // gen w and h
                rect[2] = String.valueOf(ThreadLocalRandom.current().nextInt(wmin, wmax + 1));
                rect[3] = String.valueOf(ThreadLocalRandom.current().nextInt(hmin, hmax + 1));
                allR.add(rect);
            }

            // Write data to file
            // Create customer csv
            for(String[] p: allP){
                writerP.writeNext(p);
            }
            writerP.close();

            for(String[] r: allR){
                writerR.writeNext(r);
            }
            writerR.close();

        }
        catch(IOException e){
            e.printStackTrace();
        }
    }

}
