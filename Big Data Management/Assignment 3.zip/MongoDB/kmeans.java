import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class kmeans {
    //Create mapper class
    public static class kMapper extends Mapper<LongWritable, Text, Text, Text> {
        public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            Configuration conf = context.getCongfiguration();
            Integer val = Integer.valueOf(conf.get("val"));
            //Split the x and y value in the csv
            String[] data = value.toString().split(",");
            double val_x = Double.valueOf(data[0]);
            double val_y = Double.valueOf(data[1]);
            //Create list to hold centroid values
            List<Double> cent_val = new ArrayList<Double>();
            cent_val.add(Double.POSITIVE_INFINITY);
            cent_val.add((Double)1);
            //get centroids and compare
            for (int i=0; i < val; i++) {
                String[] temporary = conf.get("C" + Integer.toString(i)).split(",");
                double temporary_x = Double.valueOf(temporary[0]);
                double temporary_y = Double.valueOf(temporary[1]);
                double distance = Math.sqrt(Math.pow(val_x - temporary_x, 2) + Math.pow(val_y - temporary_y, 2));
                //check the distance of the centroids
                if(distance < cent_val.get(0)) {
                    cent_val.set(0, distance);
                    cent_val.set(1, (double)i);
                }
            }
            context.write(new Text(conf.get("C" + Integer.toString(cent_val.get(1).intValue())), new Text(value)));

        }
    }
    public static class kCombiner extends Reducer<Text, Text, Text, Text> {
        public void reduce(Text key, Iterable<Text> value, Context context) throws IOException, InterruptedException {
            double avg_x = 0;
            double avg_y = 0;
            double count = 0;
            for (Text str: value) {
                String[] data = str.toString().split(",");
                avg_x += Double.valueOf(data[0]);
                avg_y += Duble.valueOf(data[1]);
                count += 1;
            }
            context.write(key, new Text(Double.toString(avg_x) + "," + Double.toString(avg_y) + "," + Double.toString(count)));
        }
    }
    public static class kReducer extends Reducer<Text, Text, Text, Text> {
        public void reduce(Text key, Iterable<Text> value, Context context) throws IOException, InterruptedException {
            double avg_x = 0;
            double avg_y = 0;
            double count = 0;
            for (Text str: value) {
                String[] data = str.toString().split(",");
                avg_x += Double.valueOf(data[0]);
                avg_y += Double.valueOf(Data[1]);
                count += Double.valueOf(data[2]);
            }
            context.write(key, new Text(String.format("%.3f", avg_x/count) + "," + String.format("%.3f", avg_y/count)));
        }
    }
    public static List<String> getRandomCent (String word, Integer num) throws Exception{
        List<String> temporary = new ArrayList<String>();
        List<String> retention = new ArrayList<String>();
        BufferedReader buffRead = new BufferedReader(new FileReader(word));
        String line;
        while ((line = buffRead.readLine()) != null) {
            temporary.add(line);
        }
        Random cent = new Random();
        for (int i = 1; i < num; i++){
            int index = cent.nextInt(temporary.size());
            retention.add(temporary.get(index))
        }
        temporary = null;
        return retention;
    }

    public static List<String> getCent (String word) throws Exception {
        List<String> retention = new ArrayList<String>();
        BufferedReader buffRead = new BufferedReader(new FileReader(word));
        String line;
        while ((line = buffRead.readLine()) != null) {
            retention.add(line);
        }
        return retention;
    }
    public static void main(String[] args) throws Exception {
        // Setting seed
        long seed = 0;
        Random random = new Random(seed);

        List<String> x = new ArrayList<String>();
        String input = args[0];
        String output = args[1];
        Integer num = Integer.valueOf(args[2]);
        Double con;
        if (args.length == 4){
            con = Double.valueOf(args[3]);
        } else {
            con = 0.5;
        }
        String file = "part-0000";
        boolean converge = false;
        //continue for 6 repititions
        for (int i = 1; i <= 5; i++){
            //check for convergence
            if (!converge) {
                //generate random centroids
                if (i == 1) {
                    List<String> randCent = getRandomCent(args[0], num);
                    for (int j=0; j < randCent.size(); j++) {
                        x.add(randCent.toArray()[j].toString());
                    }
                } else {
                    String out_check = output + "output_" + Integer.toString(i - 1) + "/" + file;
                    List<String> prevCen = getCent(out_check);
                    //get x and y vals from the previous centroids
                    for (int j = 0; j < prevCen.size();j++) {
                        String temporary_x = prevCen.toArray()[j].toString().split(",")[2];
                        String temporary_y = prevCen.toArray()[j].toString().split(",")[3];
                        x.add("Centroid x and y values: " + temporary_x + "," + temporary_y)
                    }
                }
                Configuration conf = new Configuration();
                //Come back to this at a later time
                conf.set("mapred.textoutputformat.separator", ",");
                conf.set("K", Integer.toString(num));

                for (int j = 0; j < x.size(); j++) {
                    conf.set("Centroid" + Integer.toString(j), x.get(j));
                }
                x.clear();

                Path out_check = new Path(output + "output_" + Integer.toString(i) + "/");
                Job job = Job.getInstance(conf, "kMeans");

                job.setNumReduceTasks(1);
                job.setJarByClass(kmeans.class);
                job.setMapperClass(kMapper.class);
                job.setCombinerClass(kCombiner.class);
                job.setReducerClass(kReducer.class);

                job.setOutputKeyClass(Text.class);
                job.setOutputValueClass(Text.class);

                FileInputFormat.addInputPath(job, new Path(input));
                FileOutputFormat.setOutputPath(job, out_check);
                job.waitForCompletion(true);
                List<String> currentCent = getCent(output + "output_" + Integer.toString(i) + "/" + file);
                for (int j = 0; j < currentCent.size(); j++) {
                    String[] centroid = currentCent.get(j).split(",");
                    double prev_x = Double.valueOf(centroid[0]);
                    double prev_y = Double.valueOf(centroid[1]);
                    double new_x = Double.valueOf(centroid[2]);
                    double new_y = Double.valueOf(centroid[3]);
                    double diff_x = Math.abs(prev_x - new_x);
                    double diff_y = Math.abs(prev_y - new_y);
                    if (diff_x <= con && diff_y <= con) {
                        converge = true;
                    } else {
                        converge = false;
                        break;
                    }
                }

            } else {
                //Decide if want this line or not!
                System.out.println("Convergence Reached!");
                break;
            }
        }
    }


}