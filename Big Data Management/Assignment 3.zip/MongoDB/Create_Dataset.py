from pathlib import Path
import os
import random
def main():
    check_and_create_P()
    check_and_create_R()
    return 0

def main_test():
    check_and_create_P_test()
    check_and_create_R_test()
    return 0

def main_centroid():
    centroid_file_path = Path(os.path.dirname(os.path.realpath(__file__)),"c.csv")
    if centroid_file_path.is_file():
        print('file C is already present, skipping')
        return 0
    print('no file C found, creating')
    k_size = random.randint(10,100)
    with open(centroid_file_path, 'a') as c_file:
        for i in range (1,k_size):
            x = random.randint(1, 10000)
            y = random.randint(1, 10000)
            c_file.write(str(x) + ',' + str(y) + os.linesep)
    return 0

def check_and_create_P():
    p_file_path = Path(os.path.dirname(os.path.realpath(__file__)),"p.csv")
    if p_file_path.is_file():
        print('file P is already present, skipping')
        return 0
    print('no file P found, creating')
    with open(p_file_path, 'a') as p_file:
        for i in range (1,100*1000*100*2):
            x = random.randint(1, 10000)
            y = random.randint(1, 10000)
            p_file.write(str(x) + ',' + str(y) + os.linesep)
    
    return 0
    
def check_and_create_R():
    r_file_path = Path(os.path.dirname(os.path.realpath(__file__)),"r.csv")
    if r_file_path.is_file():
        print('file R is already present, skipping')
        return 0
    print('no file R found, creating')
    with open(r_file_path, 'a') as p_file:
        for i in range (1,100*1000*100):
            x = random.randint(1, 10000-1)
            y = random.randint(1, 10000-1)
            height = min(random.randint(1, 20), 10000 - x)
            width = min(random.randint(1,5), 10000 - y)
            p_file.write(str(x) + ',' + str(y) + ',' +
                        str(height) + ',' + str(width) + os.linesep)
            
    return 0

def check_and_create_P_test():
    p_file_path = Path(os.path.dirname(os.path.realpath(__file__)),"p_test.csv")
    if p_file_path.is_file():
        print('file P test is already present, skipping')
        return 0
    print('no file P found, creating')
    with open(p_file_path, 'a') as p_file:
        for i in range (1,10000):
            x = random.randint(1, 10000)
            y = random.randint(1, 10000)
            p_file.write(str(x) + ',' + str(y) + os.linesep)
    
    return 0
    
def check_and_create_R_test():
    r_file_path = Path(os.path.dirname(os.path.realpath(__file__)),"r_test.csv")
    if r_file_path.is_file():
        print('file R tets is already present, skipping')
        return 0
    print('no file R found, creating')
    with open(r_file_path, 'a') as p_file:
        for i in range (1,10000):
            x = random.randint(1, 10000-1)
            y = random.randint(1, 10000-1)
            height = min(random.randint(1, 20), 10000 - x)
            width = min(random.randint(1,5), 10000 - y)
            p_file.write(str(x) + ',' + str(y) + ',' +
                        str(height) + ',' + str(width) + os.linesep)
            
    return 0
if __name__ == '__main__': 
    print(os.path.dirname(os.path.realpath(__file__)))
    # main()
    # main_test()