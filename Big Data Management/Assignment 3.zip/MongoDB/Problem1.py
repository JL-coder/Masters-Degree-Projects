from pathlib import Path
import subprocess
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType
from operator import add
from statistics import fmean
def main():
    spark_session = SparkSession.builder \
	    .master("local").appName("problem1").getOrCreate()
    step2and3(spark_session)
    return 0

def get_cell_ID(x):
    pointX = x.x
    pointY = x.y
    cellID = (((pointY // 20)+1) * 500) + (pointX // 20)
    return cellID

def get_neighbour_ID_list(cellID):
    list_of_neighbours_ids = []
    # Add neighbour above
    if cellID > 500: 
        list_of_neighbours_ids.append(cellID-500)
        if cellID % 500 != 1:
            # Add neighbour above left
            list_of_neighbours_ids.append(cellID-501)
        if cellID % 500 != 0:
            # Add neighbour above right
            list_of_neighbours_ids.append(cellID-499)

    # Add neighbour below
    if cellID < 250000-500: 
        list_of_neighbours_ids.append(cellID+500)
        if cellID % 500 != 1:
            # Add neighbour below left
            list_of_neighbours_ids.append(cellID+499)
        if cellID % 500 != 0:
            # Add neighbour below right
            list_of_neighbours_ids.append(cellID+501)
    # Add neighbour left
    if cellID % 500 != 1: list_of_neighbours_ids.append(cellID-1)
    # Add neighbour right
    if cellID % 500 != 0: list_of_neighbours_ids.append(cellID+1)
    
    return list_of_neighbours_ids

def get_neighbour_density(cellID,map):
    list_of_neighbours_ids = get_neighbour_ID_list(cellID)
    result_string = ""
    for each_neighbour_id in list_of_neighbours_ids:
        if each_neighbour_id in map:
            result_string += "neighbour cell ID: " + str(each_neighbour_id) + ", " + "density index: " + str(map[each_neighbour_id]) + "; "
    return result_string

def get_relative_density(x,map):
    # I(x) = X.count/avg(Y1.count,...,Yn.count)
    
    cellID = x[0]
    x_count = x[1]
    
    # Get neighbours around cellID
    list_of_neighbours_ids = get_neighbour_ID_list(cellID)
    list_of_neighbours_counts = []
    for each_id in list_of_neighbours_ids:
        if each_id in map:
            list_of_neighbours_counts.append(map[each_id])
        else:
            list_of_neighbours_counts.append(0)    
    x_relative_density = x_count / fmean(list_of_neighbours_counts)
    return x_relative_density

def step2and3(spark_session):
    # Read point data from hdfs
    point_schema = StructType() \
        .add('x','integer') \
        .add('y','integer')
    point_data=spark_session.read.csv("hdfs://localhost:8020/project2/p.csv",schema=point_schema)
    point_data.show(5)
    
    # Map (x,y) -> (cellID,1)
    # Then reduce (cellID,1) to (cellID,count)
    cellID_count_pair_RDD = point_data.rdd.map(lambda x: (get_cell_ID(x),1)).reduceByKey(add)
    cellID_count_pair_coll = cellID_count_pair_RDD.collect()
    count = 0
    for row in cellID_count_pair_coll:
        count += 1
        print(row[0],row[1])
        if count == 5: break
        
    # Create a map of (cellID,count)
    cellID_count_pair_map = cellID_count_pair_RDD.collectAsMap()
    print(cellID_count_pair_map[81330])

    # Calculate (cellId,density)
    cellID_density_pair_RDD = cellID_count_pair_RDD.map(lambda x: (x[0], get_relative_density(x,cellID_count_pair_map)))
    cellID_density_pair_coll = cellID_density_pair_RDD.collect()
    
    count = 0
    for row in cellID_density_pair_coll:
        count += 1
        print(row[0],row[1])
        if count == 5: break
    # save result from step2 to hdfs
    cellID_density_pair_top50_RDD = spark_session.sparkContext.parallelize(cellID_density_pair_RDD.takeOrdered(50, key = lambda x: -x[1]))
    path_step2 = "hdfs://localhost:8020/project2/problem4_step2"
    proc = subprocess.Popen(['hadoop', 'fs', '-test', '-e', path_step2])
    proc.communicate()
    # Check if file is already in hdfs
    if proc.returncode != 0:
        # not in, writing to hdfs
        print('%s does not exist' % path_step2)
        cellID_density_pair_top50_RDD.saveAsTextFile(path_step2)
    else : 
        print('%s exists' % path_step2)
    
    # Create a map for (cellID,density)
    # save result from step2 to hdfs
    cellID_density_pair_map = cellID_density_pair_RDD.collectAsMap()
    neighbour_of_top50_RDD = cellID_density_pair_top50_RDD.map(lambda x: (("Central Cell Id: "+str(x[0])), get_neighbour_density(x[0],cellID_density_pair_map)))
    path_step3 = "hdfs://localhost:8020/project2/problem1_step3"
    proc = subprocess.Popen(['hadoop', 'fs', '-test', '-e', path_step3])
    proc.communicate()
    # Check if file is already in hdfs
    if proc.returncode != 0:
        # not in, writing to hdfs
        print('%s does not exist' % path_step3)
        neighbour_of_top50_RDD.saveAsTextFile("hdfs://localhost:8020/project2/problem4_step3")
    else : 
        print('%s exists' % path_step3)
    
    return 0


if __name__ == '__main__': 
    main()