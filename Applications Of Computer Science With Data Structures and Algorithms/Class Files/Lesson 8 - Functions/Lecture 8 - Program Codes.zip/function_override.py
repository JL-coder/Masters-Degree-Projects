def do_computation():
    print("Sum")

def do_computation():
    print("Difference")

def do_computation(x):
    print(x)

def main():
    do_computation("Division")    # Do not have a value returning to the calling function

if __name__ == "__main__":
    main()