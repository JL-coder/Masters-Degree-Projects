from Node import Node

class LinkedQueue:
    def __init__(self):
        self.__head = Node(None, None)
        self.__tail = self.__head
        self.__numNodes = 1

    def getHead(self):
        return self.__head

    def setHead(self, node):
        self.__head = node

    def getTail(self):
        return self.__tail

    def setTail(self, node):
        self.__tail = node

    def getNumNodes(self):
        return self.__numNodes

    def setNumNodes(self, numNodes):
        self.__numNodes = numNodes

    def getNodeData(self, index):
        cursor = self.getHead()
        if index == 0:
            return cursor.getData()
        elif index > 0 and index < self.getNumNodes():
            for i in range(index):
                cursor = cursor.getNext()

            return cursor.getData()
        else:
            print("LinkedList Retrieval Index Out of Range")

    def setNodeData(self, index, val):
        cursor = self.getHead()
        if index == 0:
            return cursor.setData(val)
        elif index > 0 and index < self.getNumNodes():
            for i in range(index):
                cursor = cursor.getNext()

            cursor.setData(val)
        else:
            print("LinkedList Assignment Index Out of Range")

    def isEmpty(self):
        return self.getNumNodes() == 0

    def front(self):
        if self.isEmpty():
            print("Cannot dequeue from an empty queue")
        else:
            return self.getHead().getData()

    def enqueue(self, data):
        pass

    def dequeue(self):
        pass

